

// import { initializeApp } from "firebase/app";
// import { getFirestore } from "firebase/firestore"; // Import Firestore
// import 'firebase/compat/firestore';
// import firebase from 'firebase/compat/app';
// const firebaseConfig = {
//   apiKey: "AIzaSyC2sdx5i3NC1rXZkAuexNeRKlND__X-RBs",
//   authDomain: "cardsdata-f734e.firebaseapp.com",
//   projectId: "cardsdata-f734e",
//   storageBucket: "cardsdata-f734e.appspot.com", // Corrected the storage bucket URL
//   messagingSenderId: "320616615751",
//   appId: "1:320616615751:web:617f25257cb4ac35560662",
//   measurementId: "G-4886CSKYY6"
// };
// const app = firebase.initializeApp(firebaseConfig);
// export const db = firebase.firestore();



// // Initialize Firebase
// //const app = initializeApp(firebaseConfig);
// //const db = getFirestore(app); // Initialize Firestore
// // const analytics = getAnalytics(app); // Uncomment if you're using analytics

// //export { app, db }; // Export the app and db if needed elsewhere

import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database"; // Import Realtime Database
import { getStorage } from "firebase/storage"; // Import Storage

const firebaseConfig = {
  apiKey: "AIzaSyC2sdx5i3NC1rXZkAuexNeRKlND__X-RBs",
  authDomain: "cardsdata-f734e.firebaseapp.com",
  projectId: "cardsdata-f734e",
  storageBucket: "cardsdata-f734e.appspot.com",
  messagingSenderId: "320616615751",
  appId: "1:320616615751:web:617f25257cb4ac35560662",
  measurementId: "G-4886CSKYY6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Get instances of database and storage
export const database = getDatabase(app);
export const storage = getStorage(app);
